<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Задания - PHP</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f5f5;
            color: #333;
            padding: 20px;
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        h1 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 30px;
            padding-bottom: 10px;
            border-bottom: 2px solid #3498db;
        }
        
        h2 {
            color: #2980b9;
            margin: 30px 0 15px 0;
            padding-left: 10px;
            border-left: 4px solid #3498db;
        }
        
        .task {
            background-color: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border: 1px solid #e0e0e0;
        }
        
        /* Задание 1 - Таблица умножения */
        .multiplication-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        
        .multiplication-table th, .multiplication-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
            font-size: 14px;
        }
        
        .multiplication-table th {
            background-color: #3498db;
            color: white;
            font-weight: bold;
        }
        
        .multiplication-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        .multiplication-table tr:hover {
            background-color: #f1f1f1;
        }
        
        .multiplication-table td:first-child {
            background-color: #ecf0f1;
            font-weight: bold;
        }
        
        /* Задание 2 - Календарь */
        .calendar-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 20px;
        }
        
        .calendar-form {
            background-color: #ecf0f1;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            width: 300px;
        }
        
        .calendar-form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .calendar-form select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #bdc3c7;
            border-radius: 4px;
        }
        
        .calendar-form button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
        }
        
        .calendar-form button:hover {
            background-color: #2980b9;
        }
        
        .calendar {
            width: 100%;
            max-width: 800px;
            border-collapse: collapse;
            margin-top: 10px;
        }
        
        .calendar th {
            background-color: #2c3e50;
            color: white;
            padding: 12px;
            text-align: center;
            font-weight: bold;
        }
        
        .calendar td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
            height: 80px;
            vertical-align: top;
            width: 14.28%;
        }
        
        .weekend {
            background-color: #ffeaa7 !important;
            color: #d63031;
            font-weight: bold;
        }
        
        .holiday {
            background-color: #fab1a0 !important;
            color: #c23616;
            font-weight: bold;
        }
        
        .today {
            border: 3px solid #3498db !important;
            background-color: #e3f2fd !important;
        }
        
        .day-number {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .other-month {
            color: #95a5a6;
            background-color: #f9f9f9;
        }
        
        /* Задание 3 - Форма регистрации */
        .registration-form {
            background-color: #ecf0f1;
            padding: 25px;
            border-radius: 8px;
            max-width: 600px;
            margin: 0 auto;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #bdc3c7;
            border-radius: 4px;
            font-size: 16px;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #3498db;
            box-shadow: 0 0 5px rgba(52, 152, 219, 0.5);
        }
        
        .submit-btn {
            background-color: #2ecc71;
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 18px;
            width: 100%;
            transition: background-color 0.3s;
        }
        
        .submit-btn:hover {
            background-color: #27ae60;
        }
        
        .result {
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
            color: #3c763d;
            padding: 15px;
            border-radius: 4px;
            margin-top: 20px;
            display: none;
        }
        
        .error {
            background-color: #f2dede;
            border: 1px solid #ebccd1;
            color: #a94442;
            padding: 15px;
            border-radius: 4px;
            margin-top: 20px;
        }
        
        .info {
            background-color: #d9edf7;
            border: 1px solid #bce8f1;
            color: #31708f;
            padding: 10px;
            border-radius: 4px;
            margin-top: 15px;
            font-size: 14px;
        }
        
        footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            color: #7f8c8d;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Три задания на PHP</h1>
        
        <!-- Задание 1: Таблица умножения -->
        <div class="task">
            <h2>Задание 1: Таблица умножения от 0 до 10</h2>
            <table class="multiplication-table">
                <thead>
                    <tr>
                        <th>×</th>
                        <?php for($i = 0; $i <= 10; $i++): ?>
                            <th><?php echo $i; ?></th>
                        <?php endfor; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i = 0; $i <= 10; $i++): ?>
                        <tr>
                            <td><strong><?php echo $i; ?></strong></td>
                            <?php for($j = 0; $j <= 10; $j++): ?>
                                <td><?php echo $i * $j; ?></td>
                            <?php endfor; ?>
                        </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Задание 2: Календарь -->
        <div class="task">
            <h2>Задание 2: Календарь на месяц</h2>
            <div class="calendar-container">
                <form method="GET" class="calendar-form">
                    <label for="month">Выберите месяц:</label>
                    <select id="month" name="month">
                        <?php
                            $months = [
                                1 => 'Январь', 2 => 'Февраль', 3 => 'Март', 
                                4 => 'Апрель', 5 => 'Май', 6 => 'Июнь',
                                7 => 'Июль', 8 => 'Август', 9 => 'Сентябрь',
                                10 => 'Октябрь', 11 => 'Ноябрь', 12 => 'Декабрь'
                            ];
                            
                            $currentMonth = isset($_GET['month']) ? (int)$_GET['month'] : date('n');
                            $currentYear = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
                            
                            foreach($months as $num => $name) {
                                $selected = ($num == $currentMonth) ? 'selected' : '';
                                echo "<option value='$num' $selected>$name</option>";
                            }
                        ?>
                    </select>
                    
                    <label for="year">Выберите год:</label>
                    <select id="year" name="year">
                        <?php
                            $currentYear = date('Y');
                            for($year = $currentYear - 5; $year <= $currentYear + 5; $year++) {
                                $selected = ($year == $currentYear) ? 'selected' : '';
                                echo "<option value='$year' $selected>$year</option>";
                            }
                        ?>
                    </select>
                    
                    <button type="submit">Показать календарь</button>
                </form>
                
                <?php
                    // Функция для определения праздничных дней
                    function isHoliday($day, $month, $year) {
                        $holidays = [
                            '01-01' => 'Новый год',
                            '01-07' => 'Рождество Христово',
                            '02-23' => 'День защитника Отечества',
                            '03-08' => 'Международный женский день',
                            '05-01' => 'Праздник Весны и Труда',
                            '05-09' => 'День Победы',
                            '06-12' => 'День России',
                            '11-04' => 'День народного единства',
                            '12-31' => 'Новый год (канун)'
                        ];
                        
                        $dateStr = sprintf('%02d-%02d', $month, $day);
                        return isset($holidays[$dateStr]) ? $holidays[$dateStr] : false;
                    }
                    
                    // Функция для отображения календаря
                    function displayCalendar($month = null, $year = null) {
                        if ($month === null) $month = date('n');
                        if ($year === null) $year = date('Y');
                        
                        $firstDay = mktime(0, 0, 0, $month, 1, $year);
                        $daysInMonth = date('t', $firstDay);
                        $dayOfWeek = date('w', $firstDay);
                        
                        // Корректировка для воскресенья (0 -> 6)
                        if ($dayOfWeek == 0) $dayOfWeek = 6;
                        else $dayOfWeek--;
                        
                        $months = [
                            1 => 'Январь', 2 => 'Февраль', 3 => 'Март', 
                            4 => 'Апрель', 5 => 'Май', 6 => 'Июнь',
                            7 => 'Июль', 8 => 'Август', 9 => 'Сентябрь',
                            10 => 'Октябрь', 11 => 'Ноябрь', 12 => 'Декабрь'
                        ];
                        
                        echo "<h3>" . $months[$month] . " " . $year . " года</h3>";
                        echo "<table class='calendar'>";
                        echo "<tr>
                                <th>Пн</th>
                                <th>Вт</th>
                                <th>Ср</th>
                                <th>Чт</th>
                                <th>Пт</th>
                                <th class='weekend'>Сб</th>
                                <th class='weekend'>Вс</th>
                              </tr>";
                        
                        echo "<tr>";
                        
                        // Пустые ячейки перед первым днем месяца
                        for ($i = 0; $i < $dayOfWeek; $i++) {
                            $prevMonthDays = date('t', mktime(0, 0, 0, $month - 1, 1, $year));
                            $day = $prevMonthDays - ($dayOfWeek - $i - 1);
                            echo "<td class='other-month'>$day</td>";
                        }
                        
                        $currentDay = date('j');
                        $currentMonth = date('n');
                        $currentYear = date('Y');
                        
                        // Дни месяца
                        for ($day = 1; $day <= $daysInMonth; $day++) {
                            $isToday = ($day == $currentDay && $month == $currentMonth && $year == $currentYear);
                            $isWeekend = (date('N', mktime(0, 0, 0, $month, $day, $year)) >= 6);
                            $holidayName = isHoliday($day, $month, $year);
                            $isHoliday = ($holidayName !== false);
                            
                            $class = '';
                            if ($isToday) $class .= 'today ';
                            if ($isWeekend) $class .= 'weekend ';
                            if ($isHoliday) $class .= 'holiday ';
                            
                            echo "<td class='$class'>";
                            echo "<div class='day-number'>$day</div>";
                            
                            if ($isHoliday) {
                                echo "<div style='font-size: 11px; color: #c23616;'>" . $holidayName . "</div>";
                            }
                            
                            echo "</td>";
                            
                            // Новая строка в конце недели
                            if (($day + $dayOfWeek) % 7 == 0 && $day != $daysInMonth) {
                                echo "</tr><tr>";
                            }
                        }
                        
                        // Пустые ячейки после последнего дня месяца
                        $lastDayOfWeek = date('N', mktime(0, 0, 0, $month, $daysInMonth, $year));
                        if ($lastDayOfWeek < 7) {
                            for ($i = $lastDayOfWeek; $i < 7; $i++) {
                                $day = $i - $lastDayOfWeek + 1;
                                echo "<td class='other-month'>$day</td>";
                            }
                        }
                        
                        echo "</tr>";
                        echo "</table>";
                        
                        echo "<div class='info'>";
                        echo "<strong>Обозначения:</strong><br>";
                        echo "<span style='background-color: #ffeaa7; padding: 2px 5px;'>Суббота/Воскресенье</span> | ";
                        echo "<span style='background-color: #fab1a0; padding: 2px 5px;'>Праздничный день</span> | ";
                        echo "<span style='background-color: #e3f2fd; padding: 2px 5px; border: 2px solid #3498db;'>Сегодня</span>";
                        echo "</div>";
                    }
                    
                    // Получение параметров из формы или использование текущей даты
                    $month = isset($_GET['month']) ? (int)$_GET['month'] : date('n');
                    $year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
                    
                    // Проверка корректности ввода
                    if ($month < 1 || $month > 12) $month = date('n');
                    if ($year < 1900 || $year > 2100) $year = date('Y');
                    
                    // Отображение календаря
                    displayCalendar($month, $year);
                ?>
            </div>
        </div>
        
        <!-- Задание 3: Форма регистрации -->
        <div class="task">
            <h2>Задание 3: Форма регистрации пользователя</h2>
            <div class="registration-form">
                <?php
                    // Обработка формы
                    $errors = [];
                    $success = false;
                    $submitted = false;
                    
                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                        $submitted = true;
                        
                        // Валидация данных
                        $fullname = trim($_POST['fullname'] ?? '');
                        $login = trim($_POST['login'] ?? '');
                        $password = $_POST['password'] ?? '';
                        $birthdate = $_POST['birthdate'] ?? '';
                        
                        if (empty($fullname)) {
                            $errors[] = "ФИО обязательно для заполнения";
                        } elseif (strlen($fullname) < 5) {
                            $errors[] = "ФИО должно содержать не менее 5 символов";
                        }
                        
                        if (empty($login)) {
                            $errors[] = "Логин обязателен для заполнения";
                        } elseif (strlen($login) < 3) {
                            $errors[] = "Логин должен содержать не менее 3 символов";
                        } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $login)) {
                            $errors[] = "Логин может содержать только латинские буквы, цифры и символ подчеркивания";
                        }
                        
                        if (empty($password)) {
                            $errors[] = "Пароль обязателен для заполнения";
                        } elseif (strlen($password) < 6) {
                            $errors[] = "Пароль должен содержать не менее 6 символов";
                        }
                        
                        if (empty($birthdate)) {
                            $errors[] = "Дата рождения обязательна для заполнения";
                        } else {
                            $birthdateObj = DateTime::createFromFormat('Y-m-d', $birthdate);
                            if (!$birthdateObj || $birthdateObj->format('Y-m-d') !== $birthdate) {
                                $errors[] = "Неверный формат даты рождения";
                            } else {
                                $today = new DateTime();
                                $age = $birthdateObj->diff($today)->y;
                                if ($age < 18) {
                                    $errors[] = "Регистрация разрешена только с 18 лет";
                                }
                            }
                        }
                        
                        // Если нет ошибок - успешная регистрация
                        if (empty($errors)) {
                            $success = true;
                            
                            // Здесь обычно данные сохраняются в базу данных
                            // Для примера просто выводим их
                            $userData = [
                                'ФИО' => htmlspecialchars($fullname),
                                'Логин' => htmlspecialchars($login),
                                'Пароль' => '********', // В реальности пароль хешируется
                                'Дата рождения' => htmlspecialchars($birthdate),
                                'Возраст' => $age ?? 'не определен'
                            ];
                        }
                    }
                ?>
                
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="fullname">ФИО:</label>
                        <input type="text" id="fullname" name="fullname" 
                               value="<?php echo isset($_POST['fullname']) ? htmlspecialchars($_POST['fullname']) : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="login">Логин:</label>
                        <input type="text" id="login" name="login" 
                               value="<?php echo isset($_POST['login']) ? htmlspecialchars($_POST['login']) : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Пароль:</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="birthdate">Дата рождения:</label>
                        <input type="date" id="birthdate" name="birthdate" 
                               value="<?php echo isset($_POST['birthdate']) ? htmlspecialchars($_POST['birthdate']) : ''; ?>" 
                               required>
                    </div>
                    
                    <button type="submit" class="submit-btn">Зарегистрироваться</button>
                </form>
                
                <?php if ($submitted): ?>
                    <?php if ($success): ?>
                        <div class="result" style="display: block;">
                            <h3>Регистрация успешно завершена!</h3>
                            <p><strong>Данные пользователя:</strong></p>
                            <ul>
                                <?php foreach ($userData as $key => $value): ?>
                                    <li><strong><?php echo $key; ?>:</strong> <?php echo $value; ?></li>
                                <?php endforeach; ?>
                            </ul>
                            <p>В реальном приложении данные были бы сохранены в базе данных.</p>
                        </div>
                    <?php elseif (!empty($errors)): ?>
                        <div class="error">
                            <h3>Ошибки при регистрации:</h3>
                            <ul>
                                <?php foreach ($errors as $error): ?>
                                    <li><?php echo htmlspecialchars($error); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <footer>
            <p>Задания выполнены с использованием HTML, CSS, PHP</p>
            <p>Текущая дата на сервере: <?php echo date('d.m.Y H:i:s'); ?></p>
        </footer>
    </div>
</body>
</html>